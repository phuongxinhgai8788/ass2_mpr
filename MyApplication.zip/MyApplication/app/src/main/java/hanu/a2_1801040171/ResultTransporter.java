package hanu.a2_1801040171;

import java.util.List;

import hanu.a2_1801040171.models.Product;

public class ResultTransporter {
    private static ResultTransporter instance;
    private List<Product> products;
    public static ResultTransporter getInstance(){
        if(instance==null){
            instance = new ResultTransporter();
        }
        return instance;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}
