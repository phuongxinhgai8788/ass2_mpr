package hanu.a2_1801040171.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.List;

import hanu.a2_1801040171.models.Product;

public class ProductManager {
    // singleton
    private static ProductManager instance;

    private static final String INSERT_STMT =
            "INSERT INTO " + DbSchema.ProductsTable.NAME + "("+DbSchema.ProductsTable.Cols.ID+", "+DbSchema.ProductsTable.Cols.NAME+", "+DbSchema.ProductsTable.Cols.THUMBNAIL+", "+DbSchema.ProductsTable.Cols.UNIT_PRICE+", "+DbSchema.ProductsTable.Cols.QUANTITY+") VALUES (?, ?, ?, ?, ?)";

    private DbHelper dbHelper;
    private SQLiteDatabase db;

    public static ProductManager getManager(Context context) {
        if (instance == null) {
            instance = new ProductManager(context);
        }

        return instance;
    }

    private ProductManager(Context context) {
        dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public List<Product> all() {
        String sql = "SELECT * FROM "+DbSchema.ProductsTable.NAME;
        Cursor cursor = db.rawQuery(sql, null);
        ProductCursorWrapper cursorWrapper = new ProductCursorWrapper(cursor);

        return cursorWrapper.getProducts();
    }
    public List<Product> like(String input) {
        String sql = "SELECT * FROM "+DbSchema.ProductsTable.NAME + " WHERE "+DbSchema.ProductsTable.Cols.NAME + " LIKE '%"+input+"%'";
        Cursor cursor = db.rawQuery(sql, null);
        ProductCursorWrapper cursorWrapper = new ProductCursorWrapper(cursor);

        return cursorWrapper.getProducts();
    }

    /**
     * @modifies friend
     */
    public void add(Product product) {
        SQLiteStatement statement = db.compileStatement(INSERT_STMT);
        statement.bindString(2, product.getName());
        statement.bindString(3,product.getThumbnail());
        statement.bindLong(1, product.getId());
        statement.bindLong(4, product.getUnitPrice());
        statement.bindLong(5, product.getQuantity());

        statement.executeInsert();
    }
    public List<Product> productsForCart(){
        String sql = "SELECT * FROM "+DbSchema.ProductsTable.NAME +" WHERE QUANTITY > ?";
        Cursor cursor = db.rawQuery(sql, new String[]{"0"});
        ProductCursorWrapper cursorWrapper = new ProductCursorWrapper(cursor);
        return cursorWrapper.getProducts();
    }
    public void updateProduct(long id, long quantity){
        ContentValues cv = new ContentValues();
        cv.put("quantity",quantity);
        db.update(DbSchema.ProductsTable.NAME,cv,"id=?",new String[]{id+""});
    }

}
