package hanu.a2_1801040171;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import hanu.a2_1801040171.adapters.ProductAdapter;
import hanu.a2_1801040171.db.DbHelper;
import hanu.a2_1801040171.db.ProductManager;
import hanu.a2_1801040171.models.Product;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvProducts;
    private List<Product> products;
    private ProductAdapter productAdapter;
    private ProductManager productManager;
    private ImageButton cardBtn;
    private EditText search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //dataset
        productManager = ProductManager.getManager(this);
            RestLoader restLoader = new RestLoader();
            restLoader.execute("https://mpr-cart-api.herokuapp.com/products");

        products = productManager.all();
        Log.d("ITEM_COUNT",products.size()+"");

        cardBtn = findViewById(R.id.cardBtn);
        cardBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,CartActivity.class);
            startActivity(intent);

        });

        //adapter
        productAdapter = new ProductAdapter(products);
        productAdapter.notifyDataSetChanged();
        rvProducts = findViewById(R.id.rvProducts);
        rvProducts.setAdapter(productAdapter);
        rvProducts.setLayoutManager(new GridLayoutManager(this, 2));
        // search result
        search = findViewById(R.id.search_bar);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        search.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = search.getText().toString();
                Log.d("INPUT",input);
                products.clear();
                products.addAll(productManager.like(input));
                productAdapter = new ProductAdapter(products);
                productAdapter.notifyDataSetChanged();
                rvProducts.setAdapter(productAdapter);
                rvProducts.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    private class RestLoader extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            URL url;
            HttpURLConnection urlConnection;
            try {
                url = new URL(strings[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                InputStream is = urlConnection.getInputStream();
                Scanner sc = new Scanner(is);
                StringBuilder result = new StringBuilder();
                String line;
                while (sc.hasNextLine()) {
                    line = sc.nextLine();
                    result.append(line);
                }
                return result.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result == null) {
                return;
            }
            try {
                JSONArray root = new JSONArray(result);
                for (int i = 0; i < root.length(); i++) {
                    JSONObject object = root.getJSONObject(i);
                    long id = object.getLong("id");
                    String thumbnail = object.getString("thumbnail");
                    String name = object.getString("name");
                    long unit = object.getLong("unitPrice");
                    Product product = new Product(id, thumbnail, name, unit, 0);
                    try {
                        productManager.add(product);
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                    Log.d("ID",product.getId()+"");

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}