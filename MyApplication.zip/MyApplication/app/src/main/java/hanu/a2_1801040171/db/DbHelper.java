package hanu.a2_1801040171.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "blabla.db";
    private static final int DATABASE_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + DbSchema.ProductsTable.NAME + "(" +
                "id INTEGER, " +
                DbSchema.ProductsTable.Cols.THUMBNAIL + " TEXT PRIMARY KEY, " +
                DbSchema.ProductsTable.Cols.NAME + " TEXT, " +
                DbSchema.ProductsTable.Cols.QUANTITY + " INT, " +
                DbSchema.ProductsTable.Cols.UNIT_PRICE + " INT );");
    }

        // other tables her

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w("My Cart", "My Cart: upgrading DB; dropping/recreating tables.");
        db.execSQL("DROP TABLE IF EXISTS " + DbSchema.ProductsTable.NAME);

        // other tables here

        onCreate(db);
    }
}
