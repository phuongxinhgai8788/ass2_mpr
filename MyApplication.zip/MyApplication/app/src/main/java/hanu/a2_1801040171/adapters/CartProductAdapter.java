
package hanu.a2_1801040171.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import hanu.a2_1801040171.R;
import hanu.a2_1801040171.db.ProductManager;
import hanu.a2_1801040171.models.Product;

public class CartProductAdapter extends RecyclerView.Adapter<CartProductAdapter.CartProductHolder>{
    private List<Product> products;
    private Context context;
    private ProductManager manager;
    public CartProductAdapter(List<Product> products){
        this.products = manager.productsForCart();
    }
    @NonNull
    @Override
    public CartProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        context = parent.getContext();
        manager = ProductManager.getManager(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.item_cart_product, parent,false);
        return new CartProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CartProductHolder holder, int position) {
        Product product = this.products.get(position);
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return this.products.size();
    }

    public class CartProductHolder extends RecyclerView.ViewHolder{
        private ImageView imgProduct;
        private TextView tvName, tvPrice,tvQuantity,tvTotalPrice;
        private ImageButton imgButtPlus, imgButtMinus;

        public CartProductHolder(@NonNull View itemView) {
            super(itemView);
            imgProduct = itemView.findViewById(R.id.imgCartProduct);
            tvName = itemView.findViewById(R.id.tvNameCart);
            tvPrice = itemView.findViewById(R.id.tvUnitCart);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvTotalPrice = itemView.findViewById(R.id.tvTotalCart);
            imgButtPlus = itemView.findViewById(R.id.plusBtn);
            imgButtMinus = itemView.findViewById(R.id.minusBtn);
        }

        public void bind(Product product) {
            tvName.setText(product.getName());
            ImageLoader imageLoader = new ImageLoader();
            imageLoader.execute(product.getThumbnail());
            tvPrice.setText("đ "+product.getUnitPrice());
            tvQuantity.setText(product.getQuantity()+"");
            tvTotalPrice.setText(product.getUnitPrice()*product.getQuantity()+"");
            imgButtPlus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    product.setQuantity(product.getQuantity()+1);
                    manager.updateProduct(product.getId(),product.getQuantity());
                    notifyItemChanged(products.indexOf(product));
                    tvQuantity.setText(product.getQuantity()+"");
                }
            });
            imgButtMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    product.setQuantity(product.getQuantity()-1);
                    if(product.getQuantity()==0){
                        int index = products.indexOf(product);
                        products.remove(product);
                        notifyItemRemoved(index);
                    }
                    manager.updateProduct(product.getId(),product.getQuantity());
                    notifyItemChanged(products.indexOf(product));
                    tvQuantity.setText(product.getQuantity()+"");

                }
            });
        }

        private class ImageLoader extends AsyncTask<String, Void, Bitmap> {

            @Override
            protected Bitmap doInBackground(String... strings) {
                try{
                    URL url = new URL (strings[0]);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.connect();
                    InputStream is = connection.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(is);
                    return bitmap;

                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }
            @Override
            protected void onPostExecute(Bitmap bitmap){

                imgProduct.setImageBitmap(bitmap);

            }
        }
    }

}
