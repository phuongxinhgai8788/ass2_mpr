package hanu.a2_1801040171.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import hanu.a2_1801040171.R;
import hanu.a2_1801040171.db.ProductManager;
import hanu.a2_1801040171.models.Product;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductHolder>{
    private List<Product> products;
    private ProductManager manager;
    private Context context;

    public ProductAdapter(List<Product> products){
        this.products = products;
    }

    @NonNull
    @Override
    public ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.item_product, parent,false);
        return new ProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductHolder holder, int position) {
        Product product = this.products.get(position);
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return this.products.size();
    }


    public class ProductHolder extends RecyclerView.ViewHolder{
        private ImageView imgProduct;
        private TextView tvName, tvPrice;
        private ImageButton imgButt;

        public ProductHolder(@NonNull View itemView) {
            super(itemView);
            imgProduct = itemView.findViewById(R.id.imgProduct);
            tvName = itemView.findViewById(R.id.tvName);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            imgButt = itemView.findViewById(R.id.imgButt);
        }

        public void bind(Product product) {
            tvName.setText(product.getName());
            ImageLoader imageLoader = new ImageLoader();
            imageLoader.execute(product.getThumbnail());
            tvPrice.setText("đ "+product.getUnitPrice());
            imgButt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    product.setQuantity(product.getQuantity()+1);
                    manager = ProductManager.getManager(context);
                    manager.updateProduct(product.getId(),product.getQuantity());
                    notifyItemChanged(products.indexOf(product));
                }
            });
        }
        private class ImageLoader extends AsyncTask<String, Void, Bitmap> {

            @Override
            protected Bitmap doInBackground(String... strings) {
                try{
                    URL url = new URL (strings[0]);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.connect();
                    InputStream is = connection.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(is);
                    return bitmap;

                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }
            @Override
            protected void onPostExecute(Bitmap bitmap){

                imgProduct.setImageBitmap(bitmap);

            }
        }
    }
}
