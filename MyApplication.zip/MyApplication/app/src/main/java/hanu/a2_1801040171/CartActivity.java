package hanu.a2_1801040171;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.List;

import hanu.a2_1801040171.adapters.CartProductAdapter;
import hanu.a2_1801040171.adapters.ProductAdapter;
import hanu.a2_1801040171.db.ProductManager;
import hanu.a2_1801040171.models.Product;

public class CartActivity extends AppCompatActivity {
    private ProductManager productManager;
    private List<Product> products;
    private CartProductAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        //dataset
        productManager = ProductManager.getManager(this);
        products = productManager.productsForCart();

        //recyclerView
        RecyclerView recyclerView = findViewById(R.id.rvCartProducts);
        adapter = new CartProductAdapter(products);
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //TextView
        TextView tvTotal = findViewById(R.id.totalPrice);
        long totalPrice = 0;
            for (Product product : products) {
                totalPrice += product.getQuantity() + product.getUnitPrice();
            }
            tvTotal.setText("đ " + totalPrice);
    }

}